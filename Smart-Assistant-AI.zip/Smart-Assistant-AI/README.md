# Smart-Assistant-AI

This is an AI-powered voice assistant similar to Alexa or Google Assistant.

## Features
- Voice command recognition
- Opens websites
- Plays YouTube songs
- Reads latest news
- AI-generated answers
- Voice output using gTTS + pygame

## Setup Instructions
1. Install dependencies:
```
pip install -r requirements.txt
```

2. Add your API keys inside `main.py`:
```
NEWS_API_KEY = "your_news_api_key"
OPENAI_API_KEY = "your_openai_api_key"
```

3. Run the assistant:
```
python main.py
```

Say **Jarvis** to activate.
