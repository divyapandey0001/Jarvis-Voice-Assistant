music = {
    "shape of you": "https://www.youtube.com/watch?v=JGwWNGJdvx8",
    "perfect": "https://www.youtube.com/watch?v=2Vv-BfVoq4g",
    "see you again": "https://www.youtube.com/watch?v=RgKAFK5djSk"
}
